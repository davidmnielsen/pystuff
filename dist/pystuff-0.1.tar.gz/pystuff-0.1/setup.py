import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pystuff",
    version="0.1",
    author="David Nielsen",
    author_email="davidnielsen@id.uff.br",
    description="Copy-and-paste python stuff to ease your life",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/davidmnielsen/pystuff",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
